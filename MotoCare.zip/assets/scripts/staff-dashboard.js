const appointments = [
  {
    id: 1,
    date: "2025-08-27",
    time: "09:00",
    customer: "John Smith",
    vehicle: "2020 Honda Civic",
    service: "Oil Change & Filter",
    status: "confirmed",
    phone: "+63 912 345 6789",
    duration: "1 hour",
    price: "₱1,500",
  },
 
];

let currentDate = new Date();
let selectedDate = new Date();

function init() {
  updateCurrentDate();
  updateStatistics();
  generateCalendar();
  showAppointments();
}

function updateCurrentDate() {
  const today = new Date();
  const dateString = today.toLocaleDateString("en-PH", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  document.getElementById("currentDate").textContent = `Today is ${dateString}`;
}

function updateStatistics() {
  const today = formatDate(new Date());
  const todayAppointments = appointments.filter((apt) => apt.date === today);

  const stats = {
    today: todayAppointments.length,
    ongoing: appointments.filter((apt) => apt.status === "ongoing").length,
    confirmed: appointments.filter((apt) => apt.status === "confirmed").length,
    total: appointments.length,
  };

  document.getElementById("todayCount").textContent = stats.today;
  document.getElementById("ongoingCount").textContent = stats.ongoing;
  document.getElementById("confirmedCount").textContent = stats.confirmed;
  document.getElementById("totalCount").textContent = stats.total;
}

function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function navigateMonth(direction) {
  currentDate.setMonth(currentDate.getMonth() + direction);
  generateCalendar();
}

function generateCalendar() {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  document.getElementById("currentMonth").textContent =
    currentDate.toLocaleDateString("en-PH", {
      month: "long",
      year: "numeric",
    });

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDayOfWeek = firstDay.getDay();

  let calendarHTML = "";
  let dayCount = 1;
  const today = formatDate(new Date());
  const selectedDateStr = formatDate(selectedDate);

  const totalCells = Math.ceil((daysInMonth + startingDayOfWeek) / 7) * 7;

  for (let i = 0; i < totalCells; i++) {
    if (i % 7 === 0) {
      calendarHTML += '<div class="row g-0">';
    }

    if (i < startingDayOfWeek || dayCount > daysInMonth) {
      calendarHTML += '<div class="col"><div class="calendar-day"></div></div>';
    } else {
      const currentDateStr = `${year}-${String(month + 1).padStart(
        2,
        "0"
      )}-${String(dayCount).padStart(2, "0")}`;
      const dayAppointments = appointments.filter(
        (apt) => apt.date === currentDateStr
      );

      let dayClasses = "calendar-day";
      if (currentDateStr === today) dayClasses += " today";
      if (currentDateStr === selectedDateStr) dayClasses += " selected";

      let appointmentBadgesHTML = "";
      dayAppointments.forEach((apt, index) => {
        if (index < 3) {
          appointmentBadgesHTML += `<span class="appointment-badge ${apt.status}">${apt.time}</span>`;
        }
      });

      if (dayAppointments.length > 3) {
        appointmentBadgesHTML += `<small class="text-muted d-block">+${
          dayAppointments.length - 3
        } more</small>`;
      }

      calendarHTML += `
                        <div class="col">
                            <div class="${dayClasses}" onclick="selectDate('${currentDateStr}')">
                                <div class="p-2 h-100 d-flex flex-column">
                                    <div class="fw-bold mb-1">${dayCount}</div>
                                    <div class="appointment-container flex-grow-1">
                                        ${appointmentBadgesHTML}
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
      dayCount++;
    }

    if (i % 7 === 6) {
      calendarHTML += "</div>";
    }
  }

  document.getElementById("calendarGrid").innerHTML = calendarHTML;
}

function selectDate(dateString) {
  const parts = dateString.split("-");
  selectedDate = new Date(
    parseInt(parts[0]),
    parseInt(parts[1]) - 1,
    parseInt(parts[2])
  );
  generateCalendar();
  showAppointments();
}

function showAppointments() {
  const dateString = formatDate(selectedDate);
  const today = formatDate(new Date());
  const selectedAppointments = appointments.filter(
    (apt) => apt.date === dateString
  );

  const isToday = dateString === today;
  document.getElementById("appointmentsTitle").textContent = isToday
    ? "Today's Appointments"
    : "Selected Date Appointments";

  document.getElementById("selectedDateText").textContent =
    selectedDate.toLocaleDateString("en-PH", {
      weekday: "long",
      month: "long",
      day: "numeric",
    });

  let appointmentsHTML = "";

  if (selectedAppointments.length === 0) {
    appointmentsHTML = `
                    <div class="no-appointments">
                        <i class="fas fa-calendar-times fa-3x mb-3" style="color: var(--text-gray);"></i>
                        <p>No appointments for this date</p>
                    </div>
                `;
  } else {
    selectedAppointments.forEach((appointment) => {
      const statusIcon = {
        confirmed: "fa-check-circle text-success",
        ongoing: "fa-clock text-warning",
        canceled: "fa-times-circle text-danger",
      };

      appointmentsHTML += `
                        <div class="appointment-card rounded p-3 mb-3 border-start">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-clock me-2 text-muted"></i>
                                    <span class="fw-bold">${
                                      appointment.time
                                    }</span>
                                </div>
                                <span class="badge ${
                                  appointment.status === "confirmed"
                                    ? "bg-success"
                                    : appointment.status === "ongoing"
                                    ? "bg-warning"
                                    : "bg-danger"
                                }">
                                    <i class="fas ${statusIcon[
                                      appointment.status
                                    ]
                                      .split(" ")[0]
                                      .replace("fa-", "")} me-1"></i>
                                    ${
                                      appointment.status
                                        .charAt(0)
                                        .toUpperCase() +
                                      appointment.status.slice(1)
                                    }
                                </span>
                            </div>
                            
                            <div class="mb-2">
                                <div class="d-flex align-items-center mb-1">
                                    <i class="fas fa-user me-2 text-muted"></i>
                                    <strong>${appointment.customer}</strong>
                                </div>
                                <div class="d-flex align-items-center mb-1">
                                    <i class="fas fa-car me-2 text-muted"></i>
                                    <span>${appointment.vehicle}</span>
                                </div>
                                <div class="d-flex align-items-center mb-1">
                                    <i class="fas fa-wrench me-2 text-muted"></i>
                                    <span class="brand-text">${
                                      appointment.service
                                    }</span>
                                </div>
                                <div class="d-flex align-items-center mb-1">
                                    <i class="fas fa-phone me-2 text-muted"></i>
                                    <span class="text-muted">${
                                      appointment.phone
                                    }</span>
                                </div>
                                <div class="d-flex justify-content-between mt-2">
                                    <small class="text-muted">
                                        <i class="fas fa-clock me-1"></i>
                                        Duration: ${appointment.duration}
                                    </small>
                                    <small class="brand-text fw-bold">
                                        ${appointment.price}
                                    </small>
                                </div>
                            </div>
                        </div>
                    `;
    });
  }

  document.getElementById("appointmentsList").innerHTML = appointmentsHTML;
}

document.addEventListener("DOMContentLoaded", init);
